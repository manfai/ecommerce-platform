<?php return array (
  'ashallendesign/laravel-exchange-rates' => 
  array (
    'providers' => 
    array (
      0 => 'AshAllenDesign\\LaravelExchangeRates\\Providers\\ExchangeRatesProvider',
    ),
    'aliases' => 
    array (
      'ExchangeRate' => 'AshAllenDesign\\LaravelExchangeRates\\Facades\\ExchangeRate',
    ),
  ),
  'bolechen/nova-activitylog' => 
  array (
    'providers' => 
    array (
      0 => 'Bolechen\\NovaActivitylog\\ToolServiceProvider',
    ),
  ),
  'ctessier/nova-advanced-image-field' => 
  array (
    'providers' => 
    array (
      0 => 'Ctessier\\NovaAdvancedImageField\\FieldServiceProvider',
    ),
  ),
  'davidpiesse/nova-toggle' => 
  array (
    'providers' => 
    array (
      0 => 'Davidpiesse\\NovaToggle\\FieldServiceProvider',
    ),
  ),
  'dillingham/nova-attach-many' => 
  array (
    'providers' => 
    array (
      0 => 'NovaAttachMany\\Providers\\FieldServiceProvider',
    ),
  ),
  'eminiarts/nova-tabs' => 
  array (
    'providers' => 
    array (
      0 => 'Eminiarts\\Tabs\\TabsServiceProvider',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'gldrenthe89/nova-string-generator-field' => 
  array (
    'providers' => 
    array (
      0 => 'Gldrenthe89\\NovaStringGeneratorField\\NovaStringGeneratorFieldServiceProvider',
    ),
  ),
  'graham-campbell/markdown' => 
  array (
    'providers' => 
    array (
      0 => 'GrahamCampbell\\Markdown\\MarkdownServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'kabbouchi/laravel-ward' => 
  array (
    'providers' => 
    array (
      0 => 'KABBOUCHI\\Ward\\WardServiceProvider',
    ),
    'aliases' => 
    array (
      'Ward' => 'KABBOUCHI\\Ward\\Ward',
    ),
  ),
  'kabbouchi/nova-logs-tool' => 
  array (
    'providers' => 
    array (
      0 => 'KABBOUCHI\\LogsTool\\LogsToolServiceProvider',
    ),
  ),
  'laravel/nova' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Nova\\NovaCoreServiceProvider',
    ),
    'aliases' => 
    array (
      'Nova' => 'Laravel\\Nova\\Nova',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/ui' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Ui\\UiServiceProvider',
    ),
  ),
  'manfai/tripod-cats' => 
  array (
    'providers' => 
    array (
      0 => 'Manfai\\TripodCats\\ThemeServiceProvider',
    ),
  ),
  'mcamara/laravel-localization' => 
  array (
    'providers' => 
    array (
      0 => 'Mcamara\\LaravelLocalization\\LaravelLocalizationServiceProvider',
    ),
    'aliases' => 
    array (
      'LaravelLocalization' => 'Mcamara\\LaravelLocalization\\Facades\\LaravelLocalization',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nikaia/nova-rating-field' => 
  array (
    'providers' => 
    array (
      0 => 'Nikaia\\Rating\\RatingServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'optimistdigital/nova-notes-field' => 
  array (
    'providers' => 
    array (
      0 => 'OptimistDigital\\NovaNotesField\\FieldServiceProvider',
    ),
  ),
  'optimistdigital/nova-settings' => 
  array (
    'providers' => 
    array (
      0 => 'OptimistDigital\\NovaSettings\\ToolServiceProvider',
    ),
  ),
  'optimistdigital/nova-translatable' => 
  array (
    'providers' => 
    array (
      0 => 'OptimistDigital\\NovaTranslatable\\FieldServiceProvider',
    ),
  ),
  'shipping-docker/vessel' => 
  array (
    'providers' => 
    array (
      0 => 'Vessel\\VesselServiceProvider',
    ),
  ),
  'spatie/eloquent-sortable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\EloquentSortable\\EloquentSortableServiceProvider',
    ),
  ),
  'spatie/laravel-activitylog' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Activitylog\\ActivitylogServiceProvider',
    ),
  ),
  'spatie/laravel-backup' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Backup\\BackupServiceProvider',
    ),
  ),
  'spatie/laravel-tags' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Tags\\TagsServiceProvider',
    ),
  ),
  'spatie/laravel-translatable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Translatable\\TranslatableServiceProvider',
    ),
  ),
  'spatie/nova-backup-tool' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\BackupTool\\BackupToolServiceProvider',
    ),
  ),
  'spatie/nova-tags-field' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\TagsField\\TagsFieldServiceProvider',
    ),
  ),
  'whitecube/nova-flexible-content' => 
  array (
    'providers' => 
    array (
      0 => 'Whitecube\\NovaFlexibleContent\\FieldServiceProvider',
    ),
  ),
);