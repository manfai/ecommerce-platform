<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\UserPayment;
use Faker\Generator as Faker;

$factory->define(UserPayment::class, function (Faker $faker) {
    return [
        //
    ];
});
