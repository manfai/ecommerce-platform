<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\ProductTag;
use Faker\Generator as Faker;

$factory->define(ProductTag::class, function (Faker $faker) {
    return [
        //
    ];
});
