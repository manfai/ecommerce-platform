<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\UserPet;
use Faker\Generator as Faker;

$factory->define(UserPet::class, function (Faker $faker) {
    return [
        //
    ];
});
