<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\UserInvite;
use Faker\Generator as Faker;

$factory->define(UserInvite::class, function (Faker $faker) {
    return [
        //
    ];
});
