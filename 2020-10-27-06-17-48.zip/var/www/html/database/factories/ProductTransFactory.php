<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\ProductTrans;
use Faker\Generator as Faker;

$factory->define(ProductTrans::class, function (Faker $faker) {
    return [
        //
    ];
});
