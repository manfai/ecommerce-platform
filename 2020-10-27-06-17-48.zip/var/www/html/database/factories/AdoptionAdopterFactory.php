<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\AdoptionAdopter;
use Faker\Generator as Faker;

$factory->define(AdoptionAdopter::class, function (Faker $faker) {
    return [
        //
    ];
});
