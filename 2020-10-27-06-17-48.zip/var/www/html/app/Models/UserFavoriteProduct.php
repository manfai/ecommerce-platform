<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserFavoriteProduct extends Model
{
    //
}
