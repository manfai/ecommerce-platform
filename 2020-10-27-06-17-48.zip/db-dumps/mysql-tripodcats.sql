
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `action_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `batch_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actionable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actionable_id` bigint(20) unsigned NOT NULL,
  `target_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned DEFAULT NULL,
  `fields` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'running',
  `exception` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `original` text COLLATE utf8mb4_unicode_ci,
  `changes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `action_events_actionable_type_actionable_id_index` (`actionable_type`,`actionable_id`),
  KEY `action_events_batch_id_model_type_model_id_index` (`batch_id`,`model_type`,`model_id`),
  KEY `action_events_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `action_events` WRITE;
/*!40000 ALTER TABLE `action_events` DISABLE KEYS */;
INSERT INTO `action_events` VALUES (1,'91dcb2aa-ddbd-4b07-8281-293e8421fc4e',1,'Update','Spatie\\Tags\\Tag',5,'Spatie\\Tags\\Tag',5,'Spatie\\Tags\\Tag',5,'','finished','','2020-10-27 03:52:43','2020-10-27 03:52:43','{\"name\":{\"en\":\"funny\"}}','{\"name\":\"{\\\"en\\\":\\\"funnyx\\\"}\"}'),(2,'91dcb2b2-99d6-433a-9710-d2575bf48a50',1,'Update','Spatie\\Tags\\Tag',5,'Spatie\\Tags\\Tag',5,'Spatie\\Tags\\Tag',5,'','finished','','2020-10-27 03:52:48','2020-10-27 03:52:48','{\"name\":{\"en\":\"funnyx\"}}','{\"name\":\"{\\\"en\\\":\\\"funny\\\"}\"}'),(3,'91dcb351-0216-45a1-b529-38ea1ac48841',1,'Update','App\\Models\\ProductSku',20,'App\\Models\\ProductSku',20,'App\\Models\\ProductSku',20,'','finished','','2020-10-27 03:54:32','2020-10-27 03:54:32','{\"title\":{\"en\":\"nihil\"},\"stock\":32726,\"on_sale\":1}','{\"title\":\"{\\\"en\\\":\\\"nihil2\\\",\\\"zh-hk\\\":\\\"nihil2\\\",\\\"zh-cn\\\":\\\"nihil2\\\"}\",\"stock\":\"26\",\"on_sale\":true}'),(4,'91dcb473-0b21-4dda-a77c-cf8144bae07f',1,'Update','App\\Models\\Product',10,'App\\Models\\Product',10,'App\\Models\\Product',10,'','finished','','2020-10-27 03:57:42','2020-10-27 03:57:42','{\"title\":{\"en\":\"provident\"}}','{\"title\":\"{\\\"en\\\":\\\"provident\\\",\\\"zh-hk\\\":\\\"provident\\\",\\\"zh-cn\\\":\\\"provident\\\"}\"}'),(5,'91dcbe4b-b934-48d7-82b3-f1cd5f02f85d',1,'Update','App\\Models\\Product',10,'App\\Models\\Product',10,'App\\Models\\Product',10,'','finished','','2020-10-27 04:25:14','2020-10-27 04:25:14','{\"title\":{\"en\":\"provident\",\"zh-hk\":\"provident\",\"zh-cn\":\"provident\"},\"image\":\"https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn%3AANd9GcTOfVCZQf2wMjfVIYK6tLHeDSpCBQZ3om_ZBNOMICfnd_2mjcjDYx7hnf3lDw&usqp=CAc\",\"rating\":0,\"price\":\"2077.00\"}','{\"title\":\"{\\\"en\\\":\\\"\\\\u8c93\\\\u7aa9\\\",\\\"zh-hk\\\":\\\"\\\\u8c93\\\\u7aa9\\\",\\\"zh-cn\\\":\\\"\\\\u8c93\\\\u7aa9\\\"}\",\"image\":\"HzS7Kox9OpD7lDsWTCna1CIHM5xYw7cbrL2gwpgG.jpeg\",\"rating\":\"3.5\",\"price\":\"70.00\"}'),(6,'91dcc12b-4e42-4a03-a7d7-72e8e0ea06f0',1,'Update','App\\Models\\Product',10,'App\\Models\\Product',10,'App\\Models\\Product',10,'','finished','','2020-10-27 04:33:16','2020-10-27 04:33:16','{\"cost\":null}','{\"cost\":\"20\"}'),(7,'91dcc186-5d47-4e68-b7ed-8db1a38d5f86',1,'Update','App\\Models\\Product',10,'App\\Models\\Product',10,'App\\Models\\Product',10,'','finished','','2020-10-27 04:34:16','2020-10-27 04:34:16','{\"title\":{\"en\":\"\\u8c93\\u7aa9\",\"zh-hk\":\"\\u8c93\\u7aa9\",\"zh-cn\":\"\\u8c93\\u7aa9\"}}','{\"title\":\"{\\\"en\\\":\\\"\\\\u4ed9\\\\u4eba\\\\u638c\\\\u8c93\\\\u7aa9\\\",\\\"zh-hk\\\":\\\"\\\\u4ed9\\\\u4eba\\\\u638c\\\\u8c93\\\\u7aa9\\\",\\\"zh-cn\\\":\\\"\\\\u4ed9\\\\u4eba\\\\u638c\\\\u8c93\\\\u7aa9\\\"}\"}'),(8,'91dcc1a2-07f1-483a-b1b3-0860c6a51f9c',1,'Update','App\\Models\\Product',10,'App\\Models\\Product',10,'App\\Models\\Product',10,'','finished','','2020-10-27 04:34:34','2020-10-27 04:34:34','[]','[]'),(9,'91dcc256-b5f0-40df-af2e-05558186ac80',1,'Update','App\\Models\\Product',1,'App\\Models\\Product',1,'App\\Models\\Product',1,'','finished','','2020-10-27 04:36:33','2020-10-27 04:36:33','{\"title\":{\"en\":\"in\"},\"image\":\"NULL\",\"price\":\"2819.00\",\"cost\":null}','{\"title\":\"{\\\"en\\\":\\\"\\\\u7159\\\\u8089\\\\u8c93\\\\u588a\\\",\\\"zh-hk\\\":\\\"\\\\u7159\\\\u8089\\\\u8c93\\\\u588a\\\",\\\"zh-cn\\\":\\\"\\\\u7159\\\\u8089\\\\u8c93\\\\u588a\\\"}\",\"image\":\"RPrKXy810xBlQbbb1Buo7uBMBfK4BorE7gDV5CLq.jpeg\",\"price\":\"50.00\",\"cost\":\"20\"}'),(10,'91dcc3d3-4916-476b-b386-f39632bd486b',1,'Update','App\\Models\\Product',1,'App\\Models\\Product',1,'App\\Models\\Product',1,'','finished','','2020-10-27 04:40:42','2020-10-27 04:40:42','{\"image\":\"RPrKXy810xBlQbbb1Buo7uBMBfK4BorE7gDV5CLq.jpeg\"}','{\"image\":\"nVCrz29ev84VKvV7zImuz05GACKIkuhRp8J4Z0bC.jpeg\"}'),(11,'91dcc5c7-1574-4fa6-bf1f-ae5d10899d8a',1,'Update','App\\Models\\Product',1,'App\\Models\\Product',1,'App\\Models\\Product',1,'','finished','','2020-10-27 04:46:09','2020-10-27 04:46:09','{\"image\":\"nVCrz29ev84VKvV7zImuz05GACKIkuhRp8J4Z0bC.jpeg\"}','{\"image\":\"bXLsa2BnWZlrllMH4kgdWnAox8B8dDS8dPn0Mkln.jpeg\"}'),(12,'91dcc654-0d88-4f69-8734-9a1a7c693f48',1,'Update','App\\Models\\Product',1,'App\\Models\\Product',1,'App\\Models\\Product',1,'','finished','','2020-10-27 04:47:42','2020-10-27 04:47:42','{\"image\":\"bXLsa2BnWZlrllMH4kgdWnAox8B8dDS8dPn0Mkln.jpeg\"}','{\"image\":\"WSMzUF9fObbJTtGoxyRcqnedkMcqxhM5WhhqUZUo.jpeg\"}'),(13,'91dcc6f2-4b83-479e-aa17-90596b2053f0',1,'Update','App\\Models\\Product',1,'App\\Models\\Product',1,'App\\Models\\Product',1,'','finished','','2020-10-27 04:49:26','2020-10-27 04:49:26','{\"image\":\"WSMzUF9fObbJTtGoxyRcqnedkMcqxhM5WhhqUZUo.jpeg\"}','{\"image\":\"fbXnE638cY2FaeXooolAmxnjiSdrOBwcSawBEAN2.jpeg\"}'),(14,'91dcc83e-9d53-42ac-aaa9-e234e05f319d',1,'Update','App\\Models\\Product',9,'App\\Models\\Product',9,'App\\Models\\Product',9,'','finished','','2020-10-27 04:53:03','2020-10-27 04:53:03','{\"title\":{\"en\":\"quis\"},\"image\":\"https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn%3AANd9GcTuG7RGbkDMnlzgAq9RUBVOFi_Vxbc8TKq3Hdh4zp6SA4vstpMxIKFgaBKdEQ&usqp=CAc\",\"price\":\"1023.00\",\"cost\":null}','{\"title\":\"{\\\"en\\\":\\\"\\\\u6843\\\\u6843\\\\u8c93\\\\u7aa9\\\",\\\"zh-hk\\\":\\\"\\\\u6843\\\\u6843\\\\u8c93\\\\u7aa9\\\",\\\"zh-cn\\\":\\\"\\\\u6843\\\\u6843\\\\u8c93\\\\u7aa9\\\"}\",\"image\":\"Lho4LjKjZBMcAQRnURKAEyrcsf99dOo6UEPlTGag.jpeg\",\"price\":\"150.00\",\"cost\":\"100\"}'),(15,'91dcc8eb-61e5-47a7-83a2-c1ce757434cb',1,'Update','App\\Models\\Product',8,'App\\Models\\Product',8,'App\\Models\\Product',8,'','finished','','2020-10-27 04:54:57','2020-10-27 04:54:57','{\"title\":{\"en\":\"harum\"},\"image\":\"https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn%3AANd9GcTaC04_lxP01sMIv4SqxsBylQgGjU4z8uXjCGLPmyqMj0C8TozIB3bg8sTvNg&usqp=CAc\",\"price\":\"1466.00\",\"cost\":null}','{\"title\":\"{\\\"en\\\":\\\"\\\\u9152\\\\u5448\\\\u8c93\\\\u7aa9\\\",\\\"zh-hk\\\":\\\"\\\\u9152\\\\u5448\\\\u8c93\\\\u7aa9\\\",\\\"zh-cn\\\":\\\"\\\\u9152\\\\u5448\\\\u8c93\\\\u7aa9\\\"}\",\"image\":\"QaG95tunFm9ELrW7ldmCfmXWLuVyRN9tb0Au83PW.jpeg\",\"price\":\"150\",\"cost\":\"100\"}'),(16,'91dcc962-2c11-4e0b-b2d4-5ffc70eaa650',1,'Update','App\\Models\\Product',7,'App\\Models\\Product',7,'App\\Models\\Product',7,'','finished','','2020-10-27 04:56:14','2020-10-27 04:56:14','{\"title\":{\"en\":\"possimus\"},\"image\":\"https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn%3AANd9GcTaC04_lxP01sMIv4SqxsBylQgGjU4z8uXjCGLPmyqMj0C8TozIB3bg8sTvNg&usqp=CAc\",\"price\":\"4103.00\",\"cost\":null}','{\"title\":\"{\\\"en\\\":\\\"\\\\u9999\\\\u8549\\\\u8c93\\\\u7aa9\\\",\\\"zh-hk\\\":\\\"\\\\u9999\\\\u8549\\\\u8c93\\\\u7aa9\\\",\\\"zh-cn\\\":\\\"\\\\u9999\\\\u8549\\\\u8c93\\\\u7aa9\\\"}\",\"image\":\"7FkOIUJCzgmWqsjKF6m43EFZ9tlcQkJiyCq1hf3p.jpeg\",\"price\":\"90\",\"cost\":\"60\"}'),(17,'91dcca53-290a-45bb-90f5-64b1f3ac9c10',1,'Update','App\\Models\\Product',2,'App\\Models\\Product',2,'App\\Models\\Product',2,'','finished','','2020-10-27 04:58:52','2020-10-27 04:58:52','{\"title\":{\"en\":\"sunt\"},\"image\":\"https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn%3AANd9GcTgLQqb2D-89Iovsnpuxlo5Gz3L6fRJFQjVisuLGWfKsiyWu-Led4PNdOwQuA&usqp=CAc\",\"price\":\"1010.00\"}','{\"title\":\"{\\\"en\\\":\\\"\\\\u714e\\\\u86cb\\\\u5c0f\\\\u588a\\\",\\\"zh-hk\\\":\\\"\\\\u714e\\\\u86cb\\\\u5c0f\\\\u588a\\\",\\\"zh-cn\\\":\\\"\\\\u714e\\\\u86cb\\\\u5c0f\\\\u588a\\\"}\",\"image\":\"Wfsd4mOIDfDmz45ilAaExZAgDJv63p60EfBLjMHY.jpeg\",\"price\":\"50.00\"}'),(18,'91dccb23-2c4f-4066-8e0e-d2faa5ac3c49',1,'Update','App\\Models\\Product',6,'App\\Models\\Product',6,'App\\Models\\Product',6,'','finished','','2020-10-27 05:01:09','2020-10-27 05:01:09','{\"title\":{\"en\":\"impedit\"},\"image\":\"https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn%3AANd9GcTPIkjE-QYPfxOL7V7xax8hPu3tiA9Aaj0lqq3Ai97bl2_b3WGKBIMOQNaAOCA&usqp=CAc\",\"price\":\"2467.00\",\"cost\":null}','{\"title\":\"{\\\"en\\\":\\\"\\\\u8056\\\\u8a95\\\\u6a39\\\\u9020\\\\u578b\\\\u8c93\\\\u7aa9\\\",\\\"zh-hk\\\":\\\"\\\\u8056\\\\u8a95\\\\u6a39\\\\u9020\\\\u578b\\\\u8c93\\\\u7aa9\\\",\\\"zh-cn\\\":\\\"\\\\u8056\\\\u8a95\\\\u6a39\\\\u9020\\\\u578b\\\\u8c93\\\\u7aa9\\\"}\",\"image\":\"9NAf3VXEh945L6CNlzNnSwmvUGqbtOc6gngFR509.jpeg\",\"price\":\"100\",\"cost\":\"100\"}'),(19,'91dccccd-fa70-4c5c-8540-9770a23a98a0',1,'Update','App\\Models\\Product',5,'App\\Models\\Product',5,'App\\Models\\Product',5,'','finished','','2020-10-27 05:05:48','2020-10-27 05:05:48','{\"title\":{\"en\":\"nihil\"},\"image\":\"https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn%3AANd9GcTuG7RGbkDMnlzgAq9RUBVOFi_Vxbc8TKq3Hdh4zp6SA4vstpMxIKFgaBKdEQ&usqp=CAc\",\"price\":\"1087.00\",\"cost\":null}','{\"title\":\"{\\\"en\\\":\\\"\\\\u50be\\\\u659c\\\\u8c93\\\\u7897\\\",\\\"zh-hk\\\":\\\"\\\\u50be\\\\u659c\\\\u8c93\\\\u7897\\\",\\\"zh-cn\\\":\\\"\\\\u503e\\\\u659c\\\\u732b\\\\u7897\\\"}\",\"image\":\"gGjHbKWTCkBlZU6YuaVeuJ8PhFesEWqqNRTbjb3l.jpeg\",\"price\":\"30.00\",\"cost\":\"10\"}'),(20,'91dccded-197c-42ae-aa24-ee45a85483d5',1,'Update','App\\Models\\Product',4,'App\\Models\\Product',4,'App\\Models\\Product',4,'','finished','','2020-10-27 05:08:57','2020-10-27 05:08:57','{\"title\":{\"en\":\"expedita\"},\"image\":\"https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn%3AANd9GcTgLQqb2D-89Iovsnpuxlo5Gz3L6fRJFQjVisuLGWfKsiyWu-Led4PNdOwQuA&usqp=CAc\",\"rating\":1,\"price\":\"7068.00\",\"cost\":null}','{\"title\":\"{\\\"en\\\":\\\"\\\\u6162\\\\u98df\\\\u7897\\\",\\\"zh-hk\\\":\\\"\\\\u6162\\\\u98df\\\\u7897\\\",\\\"zh-cn\\\":\\\"\\\\u6162\\\\u98df\\\\u7897\\\"}\",\"image\":\"AgZuC8Feb8Ftyng0quCO1uuTICNfkWnymUS5YpQM.jpeg\",\"rating\":\"5\",\"price\":\"30.00\",\"cost\":\"10\"}'),(21,'91dcd065-ef8f-416c-a5f9-3de77b98fb33',1,'Update','App\\Models\\Product',3,'App\\Models\\Product',3,'App\\Models\\Product',3,'','finished','','2020-10-27 05:15:51','2020-10-27 05:15:51','{\"title\":{\"en\":\"aperiam\"},\"price\":\"3485.00\",\"cost\":null}','{\"title\":\"{\\\"en\\\":\\\"\\\\u8b77\\\\u9838\\\\u50be\\\\u659c\\\\u8c93\\\\u98df\\\\u76c6\\\",\\\"zh-hk\\\":\\\"\\\\u8b77\\\\u9838\\\\u50be\\\\u659c\\\\u8c93\\\\u98df\\\\u76c6\\\",\\\"zh-cn\\\":\\\"\\\\u8b77\\\\u9838\\\\u50be\\\\u659c\\\\u8c93\\\\u98df\\\\u76c6\\\"}\",\"price\":\"50.00\",\"cost\":\"10\"}'),(22,'91dcd07e-9993-42b2-aea4-242770409c68',1,'Update','App\\Models\\Product',3,'App\\Models\\Product',3,'App\\Models\\Product',3,'','finished','','2020-10-27 05:16:07','2020-10-27 05:16:07','{\"image\":\"https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn%3AANd9GcTuG7RGbkDMnlzgAq9RUBVOFi_Vxbc8TKq3Hdh4zp6SA4vstpMxIKFgaBKdEQ&usqp=CAc\"}','{\"image\":\"ZTardTSh7eRgbzbWDLqoGVuFTUejUKL3TZ9brB4b.jpeg\"}');
/*!40000 ALTER TABLE `action_events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `causer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` bigint(20) unsigned DEFAULT NULL,
  `properties` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `adoption_adopters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adoption_adopters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `adoption_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'public',
  `comment` text COLLATE utf8mb4_unicode_ci,
  `interested` tinyint(1) NOT NULL DEFAULT '0',
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `social_media` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `adoption_adopters_email_unique` (`email`),
  UNIQUE KEY `adoption_adopters_phone_unique` (`phone`),
  KEY `adoption_adopters_adoption_id_foreign` (`adoption_id`),
  KEY `adoption_adopters_user_id_foreign` (`user_id`),
  CONSTRAINT `adoption_adopters_adoption_id_foreign` FOREIGN KEY (`adoption_id`) REFERENCES `adoptions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `adoption_adopters_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `adoption_adopters` WRITE;
/*!40000 ALTER TABLE `adoption_adopters` DISABLE KEYS */;
/*!40000 ALTER TABLE `adoption_adopters` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `adoption_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adoption_uploads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adoption_id` bigint(20) unsigned NOT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filetype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'public',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `adoption_uploads_uuid_unique` (`uuid`),
  KEY `adoption_uploads_adoption_id_foreign` (`adoption_id`),
  CONSTRAINT `adoption_uploads_adoption_id_foreign` FOREIGN KEY (`adoption_id`) REFERENCES `adoptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `adoption_uploads` WRITE;
/*!40000 ALTER TABLE `adoption_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `adoption_uploads` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `adoptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adoptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `breed` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no_request',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `extra` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `adoptions_no_unique` (`no`),
  KEY `adoptions_user_id_foreign` (`user_id`),
  CONSTRAINT `adoptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `adoptions` WRITE;
/*!40000 ALTER TABLE `adoptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `adoptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `product_sku_id` bigint(20) unsigned NOT NULL,
  `qty` int(10) unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `carts_user_id_foreign` (`user_id`),
  KEY `carts_product_sku_id_foreign` (`product_sku_id`),
  CONSTRAINT `carts_product_sku_id_foreign` FOREIGN KEY (`product_sku_id`) REFERENCES `product_skus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `carts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` json NOT NULL,
  `slug` json NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_column` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'{\"en\": \"Food\"}','{\"en\": \"food\"}','product',NULL,'2020-10-22 07:47:17','2020-10-22 07:47:17'),(2,'{\"en\": \"Litter\"}','{\"en\": \"litter\"}','product',NULL,'2020-10-22 07:47:17','2020-10-22 07:47:17'),(3,'{\"en\": \"Toy\"}','{\"en\": \"toy\"}','product',NULL,'2020-10-22 07:47:17','2020-10-22 07:47:17'),(4,'{\"en\": \"Accessories\"}','{\"en\": \"accessories\"}','product',NULL,'2020-10-22 07:47:17','2020-10-22 07:47:17'),(5,'{\"en\": \"Bag & Cage\"}','{\"en\": \"bag & cage\"}','product',NULL,'2020-10-22 07:47:17','2020-10-22 07:47:17'),(6,'{\"en\": \"Beauty & Grooming\"}','{\"en\": \"beauty & grooming\"}','product',NULL,'2020-10-22 07:47:17','2020-10-22 07:47:17'),(7,'{\"en\": \"Clothing\"}','{\"en\": \"clothing\"}','product',NULL,'2020-10-22 07:47:17','2020-10-22 07:47:17'),(8,'{\"en\": \"Training\"}','{\"en\": \"training\"}','product',NULL,'2020-10-22 07:47:17','2020-10-22 07:47:17'),(9,'{\"en\": \"Others\"}','{\"en\": \"others\"}','product',NULL,'2020-10-22 07:47:17','2020-10-22 07:47:17');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categoryables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoryables` (
  `category_id` int(10) unsigned NOT NULL,
  `categoryable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoryable_id` bigint(20) unsigned NOT NULL,
  UNIQUE KEY `categoryable_id_type_unique` (`category_id`,`categoryable_id`,`categoryable_type`),
  KEY `categoryables_categoryable_type_categoryable_id_index` (`categoryable_type`,`categoryable_id`),
  CONSTRAINT `categoryables_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categoryables` WRITE;
/*!40000 ALTER TABLE `categoryables` DISABLE KEYS */;
INSERT INTO `categoryables` VALUES (4,'App\\Models\\Product',1),(4,'App\\Models\\Product',2),(4,'App\\Models\\Product',3),(4,'App\\Models\\Product',4),(4,'App\\Models\\Product',5),(4,'App\\Models\\Product',6),(4,'App\\Models\\Product',7),(4,'App\\Models\\Product',8),(4,'App\\Models\\Product',10);
/*!40000 ALTER TABLE `categoryables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(8,2) NOT NULL,
  `total` int(10) unsigned NOT NULL,
  `used` int(10) unsigned NOT NULL DEFAULT '0',
  `min_amount` decimal(10,2) NOT NULL,
  `not_before` datetime DEFAULT NULL,
  `not_after` datetime DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupons_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliveries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enable` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `deliveries` WRITE;
/*!40000 ALTER TABLE `deliveries` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliveries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `function` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(8,2) NOT NULL,
  `total` int(10) unsigned NOT NULL,
  `used` int(10) unsigned NOT NULL DEFAULT '0',
  `not_before` datetime DEFAULT NULL,
  `not_after` datetime DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `discounts_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `discounts` WRITE;
/*!40000 ALTER TABLE `discounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invitations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enable` tinyint(1) NOT NULL DEFAULT '1',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expired_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invitations_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invitations` WRITE;
/*!40000 ALTER TABLE `invitations` DISABLE KEYS */;
/*!40000 ALTER TABLE `invitations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2018_01_01_000000_create_action_events_table',1),(4,'2019_05_10_000000_add_fields_to_action_events_table',1),(5,'2019_08_13_000000_create_nova_settings_table',1),(6,'2019_09_05_083503_create_user_addresses_table',1),(7,'2019_09_06_034556_add_country_to_user_addresses',1),(8,'2019_09_07_153358_create_products_table',1),(9,'2019_09_07_153510_create_product_skus_table',1),(10,'2019_09_08_163157_create_user_favorite_products_table',1),(11,'2019_09_10_035030_create_carts_table',1),(12,'2019_09_10_150143_create_orders_table',1),(13,'2019_09_10_150252_create_order_items_table',1),(14,'2019_09_12_034441_create_payments_table',1),(15,'2019_09_12_035731_create_user_payments_table',1),(16,'2019_09_18_142142_create_failed_jobs_table',1),(17,'2019_09_22_220618_add_card_data_to_payments',1),(18,'2019_09_22_222354_create_order_payments_table',1),(19,'2019_09_23_102953_change_orders_payment_column_type',1),(20,'2019_09_23_104603_add_payment_id_to_orders',1),(21,'2019_09_23_121502_add_total_to_order_payments',1),(22,'2019_10_10_040851_create_coupons_table',1),(23,'2019_10_10_040956_orders_add_coupon_id',1),(24,'2019_10_22_000000_create_nova_notes_table',1),(25,'2019_10_22_000001_change_text_column_to_text',1),(26,'2020_07_13_141500_create_adoptions_table',1),(27,'2020_07_13_141641_create_adoption_uploads_table',1),(28,'2020_07_13_141646_create_adoption_adopters_table',1),(29,'2020_07_13_141649_create_pets_table',1),(30,'2020_07_13_141652_create_pet_uploads_table',1),(31,'2020_07_13_141656_create_user_pets_table',1),(32,'2020_07_20_050109_add_meta_to_products_table',1),(33,'2020_07_20_050634_add_meta_to_product_skus_table',1),(34,'2020_07_20_061450_create_invitations_table',1),(35,'2020_07_20_071911_create_user_invites_table',1),(36,'2020_07_20_085916_create_deliveries_table',1),(37,'2020_07_20_090012_add_ship_id_to_orders',1),(38,'2020_07_20_160814_create_settings_table',1),(39,'2020_10_19_025122_add_locale_and_currency_to_users_table',1),(40,'2020_10_19_031355_add_first_last_name_to_users_table',1),(41,'2020_10_19_031944_add_currency_to_products_table',1),(42,'2020_10_19_080516_create_tag_tables',1),(43,'2020_10_19_082024_create_order_refunds_table',1),(44,'2020_10_19_082219_create_product_comments_table',1),(45,'2020_10_19_082553_create_categories_table',1),(46,'2020_10_19_082838_create_discounts_table',1),(47,'2020_10_20_063735_create_staff_table',1),(48,'2020_10_20_091255_create_activity_log_table',1),(49,'2020_10_21_071954_create_tickets_table',1),(50,'2020_10_27_021802_add_cost_to_products_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `system` tinyint(1) NOT NULL,
  `notable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notable_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notes_notable_type_notable_id_index` (`notable_type`,`notable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `product_sku_id` bigint(20) unsigned NOT NULL,
  `qty` int(10) unsigned NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `rating` int(10) unsigned DEFAULT NULL,
  `review` text COLLATE utf8mb4_unicode_ci,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_foreign` (`order_id`),
  KEY `order_items_product_id_foreign` (`product_id`),
  KEY `order_items_product_sku_id_foreign` (`product_sku_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_product_sku_id_foreign` FOREIGN KEY (`product_sku_id`) REFERENCES `product_skus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `payment_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `failed` tinyint(1) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0.0.0.0',
  `message` text COLLATE utf8mb4_unicode_ci,
  `data` json DEFAULT NULL,
  `session` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `total` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `order_payments_order_id_foreign` (`order_id`),
  KEY `order_payments_payment_id_foreign` (`payment_id`),
  KEY `order_payments_user_id_foreign` (`user_id`),
  CONSTRAINT `order_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_payments_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_payments` WRITE;
/*!40000 ALTER TABLE `order_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_refunds` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `product_sku_id` bigint(20) unsigned NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `refund_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refund_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `refund_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refunded` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_refunds_refund_no_unique` (`refund_no`),
  KEY `order_refunds_order_id_foreign` (`order_id`),
  KEY `order_refunds_product_id_foreign` (`product_id`),
  KEY `order_refunds_product_sku_id_foreign` (`product_sku_id`),
  CONSTRAINT `order_refunds_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_refunds_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_refunds_product_sku_id_foreign` FOREIGN KEY (`product_sku_id`) REFERENCES `product_skus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_refunds` WRITE;
/*!40000 ALTER TABLE `order_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_refunds` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `use_wallet` tinyint(1) NOT NULL DEFAULT '0',
  `total_amount` decimal(10,2) NOT NULL,
  `real_amount` decimal(10,2) NOT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `paid_at` datetime DEFAULT NULL,
  `coupon_id` bigint(20) unsigned DEFAULT NULL,
  `paid_no` bigint(20) unsigned DEFAULT NULL,
  `payment_id` bigint(20) unsigned NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `refund_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `refund_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `reviewed` tinyint(1) NOT NULL DEFAULT '0',
  `ship_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `ship_data` text COLLATE utf8mb4_unicode_ci,
  `extra` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ship_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_no_unique` (`no`),
  UNIQUE KEY `orders_refund_no_unique` (`refund_no`),
  KEY `orders_user_id_foreign` (`user_id`),
  KEY `orders_payment_id_foreign` (`payment_id`),
  KEY `orders_paid_no_foreign` (`paid_no`),
  KEY `orders_coupon_id_foreign` (`coupon_id`),
  CONSTRAINT `orders_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_paid_no_foreign` FOREIGN KEY (`paid_no`) REFERENCES `order_payments` (`id`),
  CONSTRAINT `orders_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enable` tinyint(1) NOT NULL,
  `card_data` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pet_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pet_uploads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pet_id` bigint(20) unsigned NOT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filetype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'public',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pet_uploads_uuid_unique` (`uuid`),
  KEY `pet_uploads_pet_id_foreign` (`pet_id`),
  CONSTRAINT `pet_uploads_pet_id_foreign` FOREIGN KEY (`pet_id`) REFERENCES `pets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pet_uploads` WRITE;
/*!40000 ALTER TABLE `pet_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `pet_uploads` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `breed` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pets_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pets` WRITE;
/*!40000 ALTER TABLE `pets` DISABLE KEYS */;
/*!40000 ALTER TABLE `pets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `comments` text COLLATE utf8mb4_unicode_ci,
  `display` tinyint(1) NOT NULL DEFAULT '0',
  `rating` double(8,2) NOT NULL DEFAULT '5.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_comments_product_id_foreign` (`product_id`),
  KEY `product_comments_user_id_foreign` (`user_id`),
  CONSTRAINT `product_comments_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_comments` WRITE;
/*!40000 ALTER TABLE `product_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_comments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_skus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_skus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(10) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `on_sale` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `product_skus_product_id_foreign` (`product_id`),
  CONSTRAINT `product_skus_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_skus` WRITE;
/*!40000 ALTER TABLE `product_skus` DISABLE KEYS */;
INSERT INTO `product_skus` VALUES (1,'40349015','{\"en\":\"reprehenderit\"}','{\"en\":\"Repellat hic beatae aliquam ratione modi nobis.\"}',2819.00,69759,1,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(2,'94693270','{\"en\":\"blanditiis\"}','{\"en\":\"Corrupti animi rem magni.\"}',5233.00,79528,1,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(3,'75856946','{\"en\":\"neque\"}','{\"en\":\"Saepe commodi deserunt quis veniam sunt quia.\"}',7047.00,19503,2,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(4,'10135587','{\"en\":\"sequi\"}','{\"en\":\"Rem vel sunt assumenda tempore qui accusamus veritatis.\"}',1010.00,34368,2,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(5,'18901283','{\"en\":\"iste\"}','{\"en\":\"Minima rerum dicta pariatur eum suscipit sit itaque.\"}',3485.00,90235,3,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(6,'16403703','{\"en\":\"iusto\"}','{\"en\":\"Quae aliquam perspiciatis enim dignissimos.\"}',9028.00,79127,3,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(7,'99283742','{\"en\":\"ut\"}','{\"en\":\"Et odit molestiae sit voluptates illo cumque.\"}',7068.00,43486,4,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(8,'81308309','{\"en\":\"sed\"}','{\"en\":\"Totam ut mollitia ut sunt.\"}',7732.00,32882,4,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(9,'14532641','{\"en\":\"non\"}','{\"en\":\"Ipsa saepe officia molestiae est ut qui cumque magni.\"}',2332.00,49271,5,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(10,'17713207','{\"en\":\"dolor\"}','{\"en\":\"Amet eum et consequuntur in repellendus placeat.\"}',1087.00,76878,5,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(11,'93999489','{\"en\":\"saepe\"}','{\"en\":\"Quia odit inventore veritatis excepturi.\"}',2467.00,64274,6,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(12,'64860305','{\"en\":\"autem\"}','{\"en\":\"Quia earum possimus culpa consequatur exercitationem quia officiis.\"}',6880.00,66753,6,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(13,'08707970','{\"en\":\"aut\"}','{\"en\":\"Qui id vel voluptas ut numquam.\"}',8629.00,80298,7,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(14,'57291529','{\"en\":\"repellendus\"}','{\"en\":\"Unde provident voluptate quia sint delectus.\"}',4103.00,4343,7,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(15,'46634504','{\"en\":\"facere\"}','{\"en\":\"Vero vero labore et vel.\"}',1466.00,68664,8,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(16,'71011301','{\"en\":\"repellat\"}','{\"en\":\"Aperiam totam libero ipsa facilis cumque ipsa velit.\"}',6075.00,26842,8,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(17,'34942901','{\"en\":\"qui\"}','{\"en\":\"Velit possimus veritatis neque.\"}',5102.00,83133,9,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(18,'33892290','{\"en\":\"officiis\"}','{\"en\":\"Quo et aut aut ut qui quo.\"}',1023.00,60741,9,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(19,'34240946','{\"en\":\"consequatur\"}','{\"en\":\"Dolorum consectetur voluptatem saepe accusantium eos consectetur ad.\"}',9467.00,88632,10,'2020-10-22 06:57:54','2020-10-22 06:57:54',NULL,NULL,1),(20,'98647446','{\"en\":\"nihil2\",\"zh-hk\":\"nihil2\",\"zh-cn\":\"nihil2\"}','{\"en\":\"Autem ea et autem eum laudantium aut excepturi.\"}',2077.00,26,10,'2020-10-22 06:57:54','2020-10-27 03:54:32',NULL,NULL,1);
/*!40000 ALTER TABLE `product_skus` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `on_sale` tinyint(1) NOT NULL DEFAULT '1',
  `rating` double(8,2) NOT NULL DEFAULT '5.00',
  `sold_count` int(10) unsigned NOT NULL DEFAULT '0',
  `review_count` int(10) unsigned NOT NULL DEFAULT '0',
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HKD',
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'92057012','{\"en\":\"\\u7159\\u8089\\u8c93\\u588a\",\"zh-hk\":\"\\u7159\\u8089\\u8c93\\u588a\",\"zh-cn\":\"\\u7159\\u8089\\u8c93\\u588a\"}','{\"en\":\"Amet molestiae molestiae asperiores cumque totam quam ut in.\"}','fbXnE638cY2FaeXooolAmxnjiSdrOBwcSawBEAN2.jpeg',1,2.00,0,0,50.00,'2020-10-22 06:57:54','2020-10-27 04:49:26',NULL,'Asperiores quibusdam ullam velit iusto debitis.','HKD',20.00),(2,'51758851','{\"en\":\"\\u714e\\u86cb\\u5c0f\\u588a\",\"zh-hk\":\"\\u714e\\u86cb\\u5c0f\\u588a\",\"zh-cn\":\"\\u714e\\u86cb\\u5c0f\\u588a\"}','{\"en\":\"Dolorem deleniti qui reiciendis quo accusantium deleniti dolores pariatur.\"}','Wfsd4mOIDfDmz45ilAaExZAgDJv63p60EfBLjMHY.jpeg',1,2.00,0,0,50.00,'2020-10-22 06:57:54','2020-10-27 04:58:52',NULL,'Velit repellendus doloremque facilis quisquam.','HKD',NULL),(3,'06247003','{\"en\":\"\\u8b77\\u9838\\u50be\\u659c\\u8c93\\u98df\\u76c6\",\"zh-hk\":\"\\u8b77\\u9838\\u50be\\u659c\\u8c93\\u98df\\u76c6\",\"zh-cn\":\"\\u8b77\\u9838\\u50be\\u659c\\u8c93\\u98df\\u76c6\"}','{\"en\":\"Culpa explicabo inventore et sapiente.\"}','ZTardTSh7eRgbzbWDLqoGVuFTUejUKL3TZ9brB4b.jpeg',1,5.00,0,0,50.00,'2020-10-22 06:57:54','2020-10-27 05:16:07',NULL,'Vitae voluptatum iusto ducimus quia.','HKD',10.00),(4,'50150939','{\"en\":\"\\u6162\\u98df\\u7897\",\"zh-hk\":\"\\u6162\\u98df\\u7897\",\"zh-cn\":\"\\u6162\\u98df\\u7897\"}','{\"en\":\"Quibusdam quis ut suscipit illo itaque et.\"}','AgZuC8Feb8Ftyng0quCO1uuTICNfkWnymUS5YpQM.jpeg',1,5.00,0,0,30.00,'2020-10-22 06:57:54','2020-10-27 05:08:57',NULL,'Ut accusamus quod nobis iusto.','HKD',10.00),(5,'40282671','{\"en\":\"\\u50be\\u659c\\u8c93\\u7897\",\"zh-hk\":\"\\u50be\\u659c\\u8c93\\u7897\",\"zh-cn\":\"\\u503e\\u659c\\u732b\\u7897\"}','{\"en\":\"Vel autem unde perspiciatis deserunt.\"}','gGjHbKWTCkBlZU6YuaVeuJ8PhFesEWqqNRTbjb3l.jpeg',1,3.00,0,0,30.00,'2020-10-22 06:57:54','2020-10-27 05:05:48',NULL,'Blanditiis minus qui ut est magnam illo.','HKD',10.00),(6,'97483151','{\"en\":\"\\u8056\\u8a95\\u6a39\\u9020\\u578b\\u8c93\\u7aa9\",\"zh-hk\":\"\\u8056\\u8a95\\u6a39\\u9020\\u578b\\u8c93\\u7aa9\",\"zh-cn\":\"\\u8056\\u8a95\\u6a39\\u9020\\u578b\\u8c93\\u7aa9\"}','{\"en\":\"Hic et rerum ullam eos magnam nam.\"}','9NAf3VXEh945L6CNlzNnSwmvUGqbtOc6gngFR509.jpeg',1,4.00,0,0,100.00,'2020-10-22 06:57:54','2020-10-27 05:01:09',NULL,'Vero delectus dolores rerum.','HKD',100.00),(7,'36709663','{\"en\":\"\\u9999\\u8549\\u8c93\\u7aa9\",\"zh-hk\":\"\\u9999\\u8549\\u8c93\\u7aa9\",\"zh-cn\":\"\\u9999\\u8549\\u8c93\\u7aa9\"}','{\"en\":\"Voluptatem non ea animi quia.\"}','7FkOIUJCzgmWqsjKF6m43EFZ9tlcQkJiyCq1hf3p.jpeg',1,4.00,0,0,90.00,'2020-10-22 06:57:54','2020-10-27 04:56:14',NULL,'Libero reprehenderit cupiditate ipsa reiciendis voluptatem praesentium et.','HKD',60.00),(8,'04964711','{\"en\":\"\\u9152\\u5448\\u8c93\\u7aa9\",\"zh-hk\":\"\\u9152\\u5448\\u8c93\\u7aa9\",\"zh-cn\":\"\\u9152\\u5448\\u8c93\\u7aa9\"}','{\"en\":\"Ducimus eveniet molestiae possimus perspiciatis.\"}','QaG95tunFm9ELrW7ldmCfmXWLuVyRN9tb0Au83PW.jpeg',1,4.00,0,0,150.00,'2020-10-22 06:57:54','2020-10-27 04:54:57',NULL,'Incidunt minima error quae nihil sed sequi illum quia.','HKD',100.00),(9,'98641277','{\"en\":\"\\u6843\\u6843\\u8c93\\u7aa9\",\"zh-hk\":\"\\u6843\\u6843\\u8c93\\u7aa9\",\"zh-cn\":\"\\u6843\\u6843\\u8c93\\u7aa9\"}','{\"en\":\"Rerum ipsam quasi quo et.\"}','Lho4LjKjZBMcAQRnURKAEyrcsf99dOo6UEPlTGag.jpeg',1,3.00,0,0,150.00,'2020-10-22 06:57:54','2020-10-27 04:53:03',NULL,'Quia suscipit provident magni dolor inventore sunt est.','HKD',100.00),(10,'75745806','{\"en\":\"\\u4ed9\\u4eba\\u638c\\u8c93\\u7aa9\",\"zh-hk\":\"\\u4ed9\\u4eba\\u638c\\u8c93\\u7aa9\",\"zh-cn\":\"\\u4ed9\\u4eba\\u638c\\u8c93\\u7aa9\"}','{\"en\":\"Reiciendis enim quis quia magni et magnam qui id.\"}','HzS7Kox9OpD7lDsWTCna1CIHM5xYw7cbrL2gwpgG.jpeg',1,3.50,0,0,70.00,'2020-10-22 06:57:54','2020-10-27 04:34:16',NULL,'Voluptates architecto qui eaque in.','HKD',20.00);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(8192) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('address','{\"en\":\"Wong Chuk Hang\",\"zh-hk\":\"\\u9ec3\\u7af9\\u5751\",\"zh-cn\":\"\\u9ec3\\u7af9\\u5751\"}',NULL),('allow_adoption','0',NULL),('allow_login','0',NULL),('allow_registration','0',NULL),('contact','{\"email\":\"info@tripod-cats.com\",\"phone_no\":\"(852) 9351 7034\",\"address\":\"Wong Chuk Hang\"}',NULL),('copyright',NULL,NULL),('description','{\"en\":\"\\u6211\\u5011\\u70ba\\u5927\\u5bb6\\u641c\\u7f85\\u591a\\u6b3e\\u5145\\u6eff\\u8da3\\u5473\\u53ca\\u5275\\u610f\\u7684\\u5bf5\\u7269\\u7528\\u54c1\\uff0c\\u5be6\\u7528\\u4e4b\\u9918\\u4ea6\\u80fd\\u878d\\u5165\\u5bb6\\u4e2d\\u5e03\\u7f6e\\uff0c\\u589e\\u6dfb\\u6642\\u5c1a\\u611f\\uff0c\\u5feb\\u4f86\\u9078\\u8cfc\\u8b93\\u4f60\\u8207\\u5bf5\\u7269\\u5e36\\u4f86\\u5e78\\u798f\\u751f\\u6d3b\\u3002\",\"zh-hk\":\"\\u6211\\u5011\\u70ba\\u5927\\u5bb6\\u641c\\u7f85\\u591a\\u6b3e\\u5145\\u6eff\\u8da3\\u5473\\u53ca\\u5275\\u610f\\u7684\\u5bf5\\u7269\\u7528\\u54c1\\uff0c\\u5be6\\u7528\\u4e4b\\u9918\\u4ea6\\u80fd\\u878d\\u5165\\u5bb6\\u4e2d\\u5e03\\u7f6e\\uff0c\\u589e\\u6dfb\\u6642\\u5c1a\\u611f\\uff0c\\u5feb\\u4f86\\u9078\\u8cfc\\u8b93\\u4f60\\u8207\\u5bf5\\u7269\\u5e36\\u4f86\\u5e78\\u798f\\u751f\\u6d3b\\u3002\",\"zh-cn\":\"\\u6211\\u5011\\u70ba\\u5927\\u5bb6\\u641c\\u7f85\\u591a\\u6b3e\\u5145\\u6eff\\u8da3\\u5473\\u53ca\\u5275\\u610f\\u7684\\u5bf5\\u7269\\u7528\\u54c1\\uff0c\\u5be6\\u7528\\u4e4b\\u9918\\u4ea6\\u80fd\\u878d\\u5165\\u5bb6\\u4e2d\\u5e03\\u7f6e\\uff0c\\u589e\\u6dfb\\u6642\\u5c1a\\u611f\\uff0c\\u5feb\\u4f86\\u9078\\u8cfc\\u8b93\\u4f60\\u8207\\u5bf5\\u7269\\u5e36\\u4f86\\u5e78\\u798f\\u751f\\u6d3b\\u3002\"}',NULL),('maintenance','0',NULL),('open_hour','{\"weekday\":\"9am - 6pm\",\"weekend\":\"Closed\",\"holiday\":\"Closed\"}',NULL),('social_media','{\"facebook\":\"https:\\/\\/facebook.com\"}',NULL),('title','{\"en\":null,\"zh-hk\":null,\"zh-cn\":null}',NULL),('url',NULL,NULL);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `staff_code_unique` (`code`),
  UNIQUE KEY `staff_email_unique` (`email`),
  UNIQUE KEY `staff_phone_unique` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,'5eced0','Webmaster',NULL,NULL,NULL,'webmaster@example.com','','$2y$10$SBJ6otNQBDDtuKPOgrw/yuogGuGzAwgJi0m1wQW63OMzM86IbrJCi','DaHJt0tMzgsXm7QDn29cQQjosa4Z6zRDPocoGenXyPwgzfSRJmGta1CL9udU','2020-10-22 07:40:34','2020-10-22 07:40:34');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `taggables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggables` (
  `tag_id` int(10) unsigned NOT NULL,
  `taggable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taggable_id` bigint(20) unsigned NOT NULL,
  UNIQUE KEY `taggables_tag_id_taggable_id_taggable_type_unique` (`tag_id`,`taggable_id`,`taggable_type`),
  KEY `taggables_taggable_type_taggable_id_index` (`taggable_type`,`taggable_id`),
  CONSTRAINT `taggables_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `taggables` WRITE;
/*!40000 ALTER TABLE `taggables` DISABLE KEYS */;
INSERT INTO `taggables` VALUES (6,'App\\Models\\Product',1),(6,'App\\Models\\Product',2);
/*!40000 ALTER TABLE `taggables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` json NOT NULL,
  `slug` json NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_column` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (1,'{\"en\": \"cats\"}','{\"en\": \"cats\"}','product',1,'2020-10-22 07:47:17','2020-10-22 07:47:17'),(2,'{\"en\": \"cute\"}','{\"en\": \"cute\"}','product',2,'2020-10-22 07:47:17','2020-10-22 07:47:17'),(3,'{\"en\": \"kitten\"}','{\"en\": \"kitten\"}','product',3,'2020-10-22 07:47:17','2020-10-22 07:47:17'),(4,'{\"en\": \"toy\"}','{\"en\": \"toy\"}','product',4,'2020-10-22 07:47:17','2020-10-22 07:47:17'),(5,'{\"en\": \"funny\"}','{\"en\": \"funny\"}','product',5,'2020-10-22 07:47:17','2020-10-27 03:52:48'),(6,'{\"en\": \"好好味\"}','{\"en\": \"\"}','product',6,'2020-10-27 04:36:33','2020-10-27 04:36:33');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ticket_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_responses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) unsigned NOT NULL,
  `user_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_responses_ticket_id_foreign` (`ticket_id`),
  KEY `ticket_responses_user_type_user_id_index` (`user_type`,`user_id`),
  CONSTRAINT `ticket_responses_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ticket_responses` WRITE;
/*!40000 ALTER TABLE `ticket_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_responses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subject_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `causer_id` int(10) unsigned DEFAULT NULL,
  `causer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `platform` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `closed_at` timestamp NULL DEFAULT NULL,
  `closed_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tickets_subject_type_subject_id_index` (`subject_type`,`subject_id`),
  KEY `tickets_causer_id_causer_type_index` (`causer_id`,`causer_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_addresses_user_id_foreign` (`user_id`),
  CONSTRAINT `user_addresses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_addresses` WRITE;
/*!40000 ALTER TABLE `user_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_addresses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_favorite_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_favorite_products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_favorite_products_user_id_foreign` (`user_id`),
  KEY `user_favorite_products_product_id_foreign` (`product_id`),
  CONSTRAINT `user_favorite_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_favorite_products_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_favorite_products` WRITE;
/*!40000 ALTER TABLE `user_favorite_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_favorite_products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_invites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invitable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invitable_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_invites_invitable_type_invitable_id_index` (`invitable_type`,`invitable_id`),
  KEY `user_invites_user_id_foreign` (`user_id`),
  CONSTRAINT `user_invites_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_invites` WRITE;
/*!40000 ALTER TABLE `user_invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_invites` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `payment_id` bigint(20) unsigned NOT NULL,
  `default` tinyint(1) NOT NULL,
  `data` json DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_payments_user_id_foreign` (`user_id`),
  KEY `user_payments_payment_id_foreign` (`payment_id`),
  CONSTRAINT `user_payments_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_payments` WRITE;
/*!40000 ALTER TABLE `user_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_pets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_pets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pet_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_pets_pet_id_foreign` (`pet_id`),
  KEY `user_pets_user_id_foreign` (`user_id`),
  CONSTRAINT `user_pets_pet_id_foreign` FOREIGN KEY (`pet_id`) REFERENCES `pets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_pets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_pets` WRITE;
/*!40000 ALTER TABLE `user_pets` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_pets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `locale` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HKD',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_code_unique` (`code`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_phone_unique` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

